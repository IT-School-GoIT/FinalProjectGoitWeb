$(function() {
	$(".sidebarMenuScroll").overlayScrollbars({
		scrollbars : {
			visibility       : "auto",
			autoHide         : "scroll",
			autoHideDelay    : 200,
			dragScrolling    : true,
			clickScrolling   : false,
			touchSupport     : true,
			snapHandle       : false,
		},
	});
});


$(function() {
	$(".content-wrapper-scroll").overlayScrollbars({
		scrollbars : {
			visibility       : "auto",
			autoHide         : "scroll",
			autoHideDelay    : 200,
			dragScrolling    : true,
			clickScrolling   : false,
			touchSupport     : true,
			snapHandle       : false,
		},
	});
});


// Scroll 240
$(function() {
	$(".scroll240").overlayScrollbars({
		scrollbars : {
			visibility       : "auto",
			autoHide         : "scroll",
			autoHideDelay    : 200,
			dragScrolling    : true,
			clickScrolling   : false,
			touchSupport     : true,
			snapHandle       : false,
		},
	});
});


// Scroll 370
$(function() {
	$(".scroll370").overlayScrollbars({
		scrollbars : {
			visibility       : "auto",
			autoHide         : "scroll",
			autoHideDelay    : 200,
			dragScrolling    : true,
			clickScrolling   : false,
			touchSupport     : true,
			snapHandle       : false,
		},
	});
});




// Scroll 300
$(function() {
	$(".scroll300").overlayScrollbars({
		scrollbars : {
			visibility       : "auto",
			autoHide         : "scroll",
			autoHideDelay    : 200,
			dragScrolling    : true,
			clickScrolling   : false,
			touchSupport     : true,
			snapHandle       : false,
		},
	});
});





// Scroll 206
$(function() {
	$(".scroll206").overlayScrollbars({
		scrollbars : {
			visibility       : "auto",
			autoHide         : "scroll",
			autoHideDelay    : 200,
			dragScrolling    : true,
			clickScrolling   : false,
			touchSupport     : true,
			snapHandle       : false,
		},
	});
});


// Scroll 250
$(function() {
	$(".scroll250").overlayScrollbars({
		scrollbars : {
			visibility       : "auto",
			autoHide         : "scroll",
			autoHideDelay    : 200,
			dragScrolling    : true,
			clickScrolling   : false,
			touchSupport     : true,
			snapHandle       : false,
		},
	});
});


